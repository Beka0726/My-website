import SwiftUI

@main
struct FatSecretCalorieTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}